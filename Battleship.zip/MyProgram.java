/*
*Name: Battleship Project
*Author: Marco-Antonio Vega
*Date: February 27, 2020
*Summary: This program simulates a single player game of Battleship. Players have 20 attempts to find all of the enemy’s ships or they will lose. This project used 2D arrays, nested for loops, HashMaps, parallel arrays, methods, etc.
*/

import java.util.*;

public class MyProgram extends ConsoleProgram
{
    // these 2D arrays stores what the user sees and the answer key
    static Character[][] userView = {
        {'~', '~', '~', '~', '~', '~'},
        {'~', '~', '~', '~', '~', '~'},
        {'~', '~', '~', '~', '~', '~'},
        {'~', '~', '~', '~', '~', '~'},
        {'~', '~', '~', '~', '~', '~'},
        {'~', '~', '~', '~', '~', '~'}
    };
    
    static Character[][] board = {
        {'~', '~', '~', '~', '~', '~'},
        {'~', 'A', 'A', 'A', 'A', 'A'},
        {'C', '~', '~', '~', '~', '~'},
        {'C', '~', 'D', '~', '~', 'S'},
        {'~', '~', '~', '~', '~', 'S'},
        {'~', 'B', 'B', 'B', 'B', 'S'}
    }; 
    
    // stores row and column values
    static char[] letters = {'A', 'B', 'C', 'D', 'E', 'F'};
    static int[] nums = {0, 1, 2, 3, 4, 5};
    static HashMap<Character, Integer> ships = new HashMap<Character, Integer>();
    
    public void run()
    {
        printDirections();
        printUserBoard();
        
        int[] shipHits = {0, 0, 0, 0, 0};
        char[] shipLetters = {'A', 'B', 'S', 'C', 'D'};
        
        //adds keys and value to hashmap
        ships.put('A',5);
        ships.put('B',4);
        ships.put('S',3);
        ships.put('C',2);
        ships.put('D',1);
        
        System.out.println("");
        
        //ensures that player only gets 20 tries
        int tries = 0;
        while (tries != 20)
        {
            String rowString = readLine("\n\nPlease enter in a letter to indicate the row: ");
            rowString = rowString.toUpperCase();
            char rowChar = rowString.charAt(0);
            int column = readInt("Please enter in a number to indicate the column: ");
            
            //checks if input is valid
            if (checkSlot(rowChar, column, shipLetters, shipHits))
            {
                tries++;
                printUserBoard();
            }
            
            //if wrong input, allows for another input without increasing tries
            else
            {
                System.out.println("\nWrong input. Try again.");
            }
            
            //checks if player has sunk all ships
            if (checkWinner(shipLetters, shipHits))
            {
                System.out.println("\n\nYou sunk all the ships! Game over.");
                break;
            }
        }
        
        //announces end of game if 20 tries is exceeded and still have not sunk all ships
        if (checkWinner(shipLetters, shipHits) == false)
        {
            System.out.println("\n\n\nYou ran out of attempts! Game over.\n");
            System.out.println("~~This is the winning board~~\n\n");
            printBoard();
        }
        
        System.out.println("\n\nThanks for playing!");
    }
    
    public void printDirections()
    {
        System.out.println("\t\tWelcome to the game of Battleship!\n"
        + "Your job is to uncover all of the hidden ships on the board.\n"
        + "You will enter a letter for a row (A - F) and a number for\n"
        + "the column (0 - 5) to undicate which spot you want to hit.\n"
        + "\nThere are 5 ships you will need to find:\n"
	    + "\tThe Aircraft Carrier (A) -- covers 5 slots\n"
	    + "\tThe Battleship (B) -- covers 4 slots\n"
	    + "\tThe Submarine (S) -- covers 3 slots\n"
	    + "\tThe Cruiser (C) -- covers 2 slots\n"
	    + "\tThe Destroyer (D) -- covers 1 slot\n"
        + "\nYou have 20 attempts to uncover all of the enemies ships.\n"
        + "Good luck!");
        System.out.println("");
    }
    
    public void printUserBoard()
    {
        System.out.print("\t");
        for (int i = 0; i <nums.length; i++)
        {
            System.out.print(nums[i] + "\t");
        }
        
        for (int i = 0; i < letters.length; i++)
        {
            System.out.print( "\n" + letters[i]);
            for (int j = 0; j < letters.length; j++)
            {
                System.out.print("\t" + userView[i][j]);
            }
        }
   	}
   	
   	public void printBoard()
    {
        System.out.print("\t");
        for (int i = 0; i <nums.length; i++)
        {
            System.out.print(nums[i] + "\t");
        }
        
        for (int i = 0; i < letters.length; i++)
        {
            System.out.print( "\n" + letters[i]);
            for (int j = 0; j < letters.length; j++)
            {
                System.out.print("\t" + board[i][j]);
            }
        }
   	}
   	
   	public boolean checkSlot(char row, int col, char[] shipLetters, int[] shipHits)
    {
        boolean rowCheck = false;
  
        for (int i = 0; i < letters.length; i++)
        {
            if (letters[i] == row)
            {
                rowCheck = true;
            }
        }
        
        boolean colCheck = false;
        
        for (int i = 0; i < letters.length; i++)
        {
            if (nums[i] == col)
            {
                colCheck = true;
            }
        }
        
        boolean finalCheck = false;
        
        if (rowCheck && colCheck)
        {
            int rowIndex = 0;
            for (int i = 0; i < letters.length; i++)
            {
                if (letters[i] == row)
                {
                    rowIndex = i;
                }
            }
            
            int newRow = rowIndex;
            
            if (board[newRow][col] == '*')
            {
                finalCheck = false;
            }
            
            else if (board[newRow][col] == '~')
            {
                board[newRow][col] = '*';
                userView[newRow][col] = '*';
                System.out.println("\nYou missed. Better luck next time.\n");
                finalCheck = true;
            }
            
            else
            {
                int index = 0;
                userView[newRow][col] = board[newRow][col];
                
                for (int i = 0; i < shipLetters.length; i++)
                {
                    if (userView[newRow][col] == shipLetters[i])
                    {
                        index = i;
                    }
                }
                
                System.out.println("\nYou hit something!\n");
                shipHits[index]++;
                finalCheck = true;
            }
        }
        
        else
        {
            finalCheck = false;
        }
        
        return finalCheck;
   	}
   	
   	public boolean checkWinner(char[] shipLetters, int[] shipHits)
   	{
   	    boolean check = false;
   	    int win = 0;
   	    
   	    for (int i = 0; i < shipHits.length; i++)
   	    {
   	        if (shipHits[i] == ships.get(shipLetters[i]))
   	        {
   	            win++;
   	        }
   	    }
   	    
   	    if (win == 5)
   	    {
   	        check = true;
   	    }
   	    
   	    return check;
   	}
}